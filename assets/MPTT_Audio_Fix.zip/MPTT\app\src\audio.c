/**
 * audio.c - I2S2时分复用音频驱动
 * 支持INMP441录音 + MAX98357播放
 */

#include "audio.h"
#include "audio_config.h"
#include "ringbuffer16.h"
#include "stm32wlxx_hal.h"

// I2S句柄
I2S_HandleTypeDef hi2s2;

// DMA句柄
DMA_HandleTypeDef hdma_spi2_tx;
DMA_HandleTypeDef hdma_spi2_rx;

// 音频模式
static volatile enum {
    AUDIO_MODE_IDLE = 0,
    AUDIO_MODE_CAPTURE,
    AUDIO_MODE_PLAYBACK
} audio_mode = AUDIO_MODE_IDLE;

// 录音相关
static AudioCaptureCallback capture_cb = NULL;
static int32_t capture_dma_buffer[AUDIO_DMA_CAPTURE_WORDS * 2];
static volatile bool capture_running = false;

// 播放相关
static int16_t playback_fifo_storage[AUDIO_PLAYBACK_FIFO_SAMPLES + 1];
static RingBuffer16 playback_fifo;
static int16_t playback_dma_buffer[AUDIO_DMA_PLAYBACK_SAMPLES];
static volatile bool playback_running = false;

// 调试计数
static volatile uint32_t capture_irq_count = 0;
static volatile uint32_t playback_irq_count = 0;

/**
 * @brief 初始化音频系统
 */
void Audio_Init(void) {
    // 初始化播放FIFO
    RingBuffer16_Init(&playback_fifo, playback_fifo_storage, 
                      (uint16_t)(AUDIO_PLAYBACK_FIFO_SAMPLES + 1));
    
    // 初始化I2S2
    I2S2_Init();
    
    audio_mode = AUDIO_MODE_IDLE;
    capture_running = false;
    playback_running = false;
}

/**
 * @brief 初始化I2S2
 */
void I2S2_Init(void) {
    hi2s2.Instance = SPI2;
    hi2s2.Init.Mode = I2S_MODE_MASTER_TX;  // 默认发送模式
    hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
    hi2s2.Init.DataFormat = I2S_DATAFORMAT_16B;
    hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_DISABLE;
    hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_16K;
    hi2s2.Init.CPOL = I2S_CPOL_LOW;
    
    if (HAL_I2S_Init(&hi2s2) != HAL_OK) {
        Error_Handler();
    }
}

/**
 * @brief 重新配置I2S模式
 */
static bool I2S_Reconfig(uint32_t mode) {
    // 停止当前传输
    HAL_I2S_DMAStop(&hi2s2);
    
    // 重新初始化
    HAL_I2S_DeInit(&hi2s2);
    
    hi2s2.Init.Mode = mode;
    if (HAL_I2S_Init(&hi2s2) != HAL_OK) {
        return false;
    }
    
    return true;
}

/**
 * @brief 设置录音回调
 */
void Audio_SetCaptureCallback(AudioCaptureCallback cb) {
    capture_cb = cb;
}

/**
 * @brief 处理录音数据
 */
static void process_capture_data(const int32_t* src, uint16_t n_samples) {
    if (!capture_cb) return;
    
    static int16_t pcm_buffer[AUDIO_FRAME_SAMPLES];
    uint16_t n = (n_samples > AUDIO_FRAME_SAMPLES) ? AUDIO_FRAME_SAMPLES : n_samples;
    
    // 32位转16位
    for (uint16_t i = 0; i < n; i++) {
        int32_t v = src[i] >> AUDIO_CAPTURE_SHIFT_RIGHT;
        if (v > 32767) v = 32767;
        else if (v < -32768) v = -32768;
        pcm_buffer[i] = (int16_t)v;
    }
    
    capture_cb(pcm_buffer, n);
}

/**
 * @brief 开始录音
 */
bool Audio_StartCapture(void) {
    if (audio_mode == AUDIO_MODE_CAPTURE) {
        return true;
    }
    
    // 如果正在播放，先停止
    if (audio_mode == AUDIO_MODE_PLAYBACK) {
        Audio_StopPlayback();
    }
    
    // 重新配置为接收模式
    if (!I2S_Reconfig(I2S_MODE_MASTER_RX)) {
        return false;
    }
    
    // 启动DMA接收
    if (HAL_I2S_Receive_DMA(&hi2s2, (uint16_t*)capture_dma_buffer, 
                            AUDIO_DMA_CAPTURE_WORDS * 2) != HAL_OK) {
        return false;
    }
    
    audio_mode = AUDIO_MODE_CAPTURE;
    capture_running = true;
    return true;
}

/**
 * @brief 停止录音
 */
void Audio_StopCapture(void) {
    if (audio_mode != AUDIO_MODE_CAPTURE) return;
    
    HAL_I2S_DMAStop(&hi2s2);
    capture_running = false;
    audio_mode = AUDIO_MODE_IDLE;
}

/**
 * @brief 填充播放DMA缓冲区
 */
static void fill_playback_buffer(uint16_t half_idx) {
    uint16_t half = AUDIO_DMA_PLAYBACK_SAMPLES / 2;
    uint16_t offset = half_idx * half;
    uint16_t stereo_samples = half / 2;
    
    int16_t mono_buffer[AUDIO_DMA_PLAYBACK_SAMPLES / 4];
    uint16_t got = RingBuffer16_Pop(&playback_fifo, mono_buffer, stereo_samples);
    
    // 转换为立体声
    for (uint16_t i = 0; i < stereo_samples; i++) {
        int16_t sample = (i < got) ? mono_buffer[i] : 0;
        playback_dma_buffer[offset + i * 2 + 0] = sample;
        playback_dma_buffer[offset + i * 2 + 1] = sample;
    }
}

/**
 * @brief 开始播放
 */
bool Audio_StartPlayback(void) {
    if (audio_mode == AUDIO_MODE_PLAYBACK) {
        return true;
    }
    
    // 如果正在录音，先停止
    if (audio_mode == AUDIO_MODE_CAPTURE) {
        Audio_StopCapture();
    }
    
    // 重新配置为发送模式
    if (!I2S_Reconfig(I2S_MODE_MASTER_TX)) {
        return false;
    }
    
    // 预填充DMA缓冲区
    fill_playback_buffer(0);
    fill_playback_buffer(1);
    
    // 启动DMA发送
    if (HAL_I2S_Transmit_DMA(&hi2s2, (uint16_t*)playback_dma_buffer, 
                             AUDIO_DMA_PLAYBACK_SAMPLES) != HAL_OK) {
        return false;
    }
    
    audio_mode = AUDIO_MODE_PLAYBACK;
    playback_running = true;
    return true;
}

/**
 * @brief 停止播放
 */
void Audio_StopPlayback(void) {
    if (audio_mode != AUDIO_MODE_PLAYBACK) return;
    
    HAL_I2S_DMAStop(&hi2s2);
    playback_running = false;
    audio_mode = AUDIO_MODE_IDLE;
}

/**
 * @brief 推送播放数据
 */
bool Audio_PlaybackPush(const int16_t* pcm, uint16_t samples) {
    return RingBuffer16_Push(&playback_fifo, pcm, samples);
}

/**
 * @brief 获取音频模式
 */
uint8_t Audio_GetMode(void) {
    return (uint8_t)audio_mode;
}

/**
 * @brief 获取调试计数
 */
void Audio_GetStats(uint32_t* cap_count, uint32_t* pb_count) {
    if (cap_count) *cap_count = capture_irq_count;
    if (pb_count) *pb_count = playback_irq_count;
}

// ========== HAL回调函数 ==========

void HAL_I2S_RxHalfCpltCallback(I2S_HandleTypeDef* hi2s) {
    if (hi2s != &hi2s2) return;
    capture_irq_count++;
    process_capture_data(capture_dma_buffer, AUDIO_DMA_CAPTURE_WORDS);
}

void HAL_I2S_RxCpltCallback(I2S_HandleTypeDef* hi2s) {
    if (hi2s != &hi2s2) return;
    capture_irq_count++;
    process_capture_data(capture_dma_buffer + AUDIO_DMA_CAPTURE_WORDS, AUDIO_DMA_CAPTURE_WORDS);
}

void HAL_I2S_TxHalfCpltCallback(I2S_HandleTypeDef* hi2s) {
    if (hi2s != &hi2s2) return;
    playback_irq_count++;
    fill_playback_buffer(0);
}

void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef* hi2s) {
    if (hi2s != &hi2s2) return;
    playback_irq_count++;
    fill_playback_buffer(1);
}

// ========== DMA中断处理 ==========

void DMA1_Channel1_IRQHandler(void) {
    HAL_DMA_IRQHandler(&hdma_spi2_tx);
}

void DMA1_Channel2_IRQHandler(void) {
    HAL_DMA_IRQHandler(&hdma_spi2_rx);
}
