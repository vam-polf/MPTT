/**
 * app_test.c - 音频回环测试版本
 * 直接替换原有的app.c进行测试
 */

#include "app.h"
#include "audio.h"
#include "audio_config.h"
#include "board_pins.h"
#include "stm32wlxx_hal.h"
#include <stdio.h>
#include <string.h>

// 测试模式
#define TEST_MODE_LOOPBACK 1  // 1=自动回环, 0=PTT控制

// 录音缓冲区 (2秒 @ 16kHz)
#define RECORD_SIZE (16000 * 2)
static int16_t record_buffer[RECORD_SIZE];
static volatile uint32_t record_idx = 0;
static volatile bool is_recording = false;

// 录音回调
static void capture_cb(const int16_t* pcm, uint16_t samples) {
    if (!is_recording) return;
    for (uint16_t i = 0; i < samples && record_idx < RECORD_SIZE; i++) {
        record_buffer[record_idx++] = pcm[i];
    }
}

// PTT检测
static bool ptt_pressed(void) {
    return HAL_GPIO_ReadPin(PTT_GPIO_PORT, PTT_PIN) == GPIO_PIN_RESET;
}

// 延时
static void delay_ms(uint32_t ms) {
    HAL_Delay(ms);
}

// 自动回环测试
static void auto_loopback_test(void) {
    printf("\r\n========== 自动回环测试 ==========\r\n");
    printf("录音1秒 -> 播放1秒 -> 循环\r\n");
    printf("==================================\r\n\r\n");
    
    Audio_SetCaptureCallback(capture_cb);
    
    while (1) {
        // 录音
        printf("[录音] ");
        memset(record_buffer, 0, sizeof(record_buffer));
        record_idx = 0;
        is_recording = true;
        
        if (!Audio_StartCapture()) {
            printf("失败!\r\n");
            delay_ms(1000);
            continue;
        }
        
        delay_ms(1000);
        is_recording = false;
        Audio_StopCapture();
        printf("完成 (%lu样本)\r\n", record_idx);
        
        delay_ms(100);
        
        // 播放
        printf("[播放] ");
        uint32_t to_play = record_idx;
        uint32_t pushed = 0;
        
        while (pushed < to_play) {
            uint16_t chunk = (to_play - pushed > 64) ? 64 : (uint16_t)(to_play - pushed);
            if (Audio_PlaybackPush(&record_buffer[pushed], chunk)) {
                pushed += chunk;
            } else {
                delay_ms(2);
            }
        }
        
        if (!Audio_StartPlayback()) {
            printf("失败!\r\n");
            delay_ms(1000);
            continue;
        }
        
        delay_ms(1000 + (to_play / 16));
        Audio_StopPlayback();
        printf("完成\r\n\r\n");
        
        delay_ms(300);
    }
}

// PTT控制测试
static void ptt_test(void) {
    printf("\r\n========== PTT控制测试 ==========\r\n");
    printf("按住PTT录音，松开播放\r\n");
    printf("=================================\r\n\r\n");
    
    Audio_SetCaptureCallback(capture_cb);
    bool last_ptt = false;
    
    while (1) {
        bool ptt = ptt_pressed();
        
        if (ptt && !last_ptt) {
            printf("[PTT按下] 录音开始\r\n");
            Audio_StopPlayback();
            delay_ms(20);
            
            memset(record_buffer, 0, sizeof(record_buffer));
            record_idx = 0;
            is_recording = true;
            Audio_StartCapture();
        }
        
        if (!ptt && last_ptt) {
            printf("[PTT松开] 录音结束 (%lu样本)，播放开始\r\n", record_idx);
            is_recording = false;
            Audio_StopCapture();
            delay_ms(20);
            
            uint32_t to_play = record_idx;
            for (uint32_t i = 0; i < to_play; ) {
                uint16_t chunk = (to_play - i > 64) ? 64 : (uint16_t)(to_play - i);
                if (Audio_PlaybackPush(&record_buffer[i], chunk)) {
                    i += chunk;
                } else {
                    delay_ms(2);
                }
            }
            
            Audio_StartPlayback();
        }
        
        last_ptt = ptt;
        delay_ms(10);
    }
}

// App初始化
void App_Init(void) {
    printf("\r\nMPTT Audio Test\r\n");
    printf("===============\r\n");
    
    Audio_Init();
    printf("Audio init OK\r\n");
    
#if TEST_MODE_LOOPBACK
    auto_loopback_test();
#else
    ptt_test();
#endif
}

// App主循环（不会执行到这里）
void App_Loop(void) {
}

// 无线电回调（空实现）
void App_OnRadioRx(const uint8_t* data, uint16_t len, int16_t rssi, int8_t snr) {
    (void)data; (void)len; (void)rssi; (void)snr;
}

void App_OnRadioTxDone(void) {
}

void App_OnRadioTxTimeout(void) {
}

// PTT状态
bool App_PttPressed(void) {
    return ptt_pressed();
}
