========================================
MPTT 音频调试 - 修复文件包
========================================

使用方法：

1. 备份原有文件
   - 备份 D:\mptt\test-mptt\Core\Src\stm32wlxx_hal_msp.c
   - 备份 D:\mptt\test-mptt\Core\Src\stm32wlxx_it.c
   - 备份 D:\mptt\test-mptt\Core\Inc\main.h
   - 备份 D:\mptt\MPTT\firmware\app\src\audio.c
   - 备份 D:\mptt\MPTT\firmware\app\inc\audio.h
   - 备份 D:\mptt\MPTT\firmware\app\src\app.c
   - 备份 D:\mptt\MPTT\firmware\app\inc\audio_config.h

2. 复制修复文件到对应目录
   - Core\Src\stm32wlxx_hal_msp.c → D:\mptt\test-mptt\Core\Src\
   - Core\Src\stm32wlxx_it.c → D:\mptt\test-mptt\Core\Src\
   - Core\Inc\main.h → D:\mptt\test-mptt\Core\Inc\
   - MPTT\app\src\audio.c → D:\mptt\MPTT\firmware\app\src\
   - MPTT\app\inc\audio.h → D:\mptt\MPTT\firmware\app\inc\
   - MPTT\app\src\app.c → D:\mptt\MPTT\firmware\app\src\
   - MPTT\app\inc\audio_config.h → D:\mptt\MPTT\firmware\app\inc\

3. 用STM32CubeIDE打开项目
   - 打开 D:\mptt\test-mptt
   - 右键项目 → Build Project

4. 下载测试
   - 连接ST-Link
   - 下载程序
   - 打开串口助手 (115200)
   - 复位设备

5. 预期结果
   - 串口输出：MPTT Audio Test
   - 自动录音1秒，播放1秒，循环
   - 对着麦克风说话，1秒后听到回放

========================================
