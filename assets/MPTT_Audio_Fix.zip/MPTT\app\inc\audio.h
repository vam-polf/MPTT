/**
 * audio.h - I2S2时分复用音频驱动头文件
 */

#pragma once

#include <stdbool.h>
#include <stdint.h>

// 回调函数类型
typedef void (*AudioCaptureCallback)(const int16_t* pcm, uint16_t samples);

// I2S句柄外部声明
extern I2S_HandleTypeDef hi2s2;
extern DMA_HandleTypeDef hdma_spi2_tx;
extern DMA_HandleTypeDef hdma_spi2_rx;

/**
 * @brief 初始化音频系统
 */
void Audio_Init(void);

/**
 * @brief 初始化I2S2
 */
void I2S2_Init(void);

/**
 * @brief 设置录音回调函数
 */
void Audio_SetCaptureCallback(AudioCaptureCallback cb);

/**
 * @brief 开始录音
 * @return true成功, false失败
 */
bool Audio_StartCapture(void);

/**
 * @brief 停止录音
 */
void Audio_StopCapture(void);

/**
 * @brief 开始播放
 * @return true成功, false失败
 */
bool Audio_StartPlayback(void);

/**
 * @brief 停止播放
 */
void Audio_StopPlayback(void);

/**
 * @brief 推送播放数据到FIFO
 * @param pcm PCM数据指针
 * @param samples 样本数
 * @return true成功, false失败(FIFO满)
 */
bool Audio_PlaybackPush(const int16_t* pcm, uint16_t samples);

/**
 * @brief 获取当前音频模式
 * @return 0=空闲, 1=录音, 2=播放
 */
uint8_t Audio_GetMode(void);

/**
 * @brief 获取调试统计
 */
void Audio_GetStats(uint32_t* cap_count, uint32_t* pb_count);

// DMA中断处理
void DMA1_Channel1_IRQHandler(void);
void DMA1_Channel2_IRQHandler(void);
