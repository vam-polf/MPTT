/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : MPTT Audio Test - INMP441 + MAX98357
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>
#include <string.h>

/* Private variables ---------------------------------------------------------*/
I2S_HandleTypeDef hi2s2;
DMA_HandleTypeDef hdma_spi2_tx;
DMA_HandleTypeDef hdma_spi2_rx;

UART_HandleTypeDef hlpuart1;

/* USER CODE BEGIN PV */
// 音频缓冲区
#define AUDIO_BUFFER_SIZE 256
#define RECORD_BUFFER_SIZE (16000 * 2)  // 2秒 @ 16kHz

static int16_t audio_buffer[AUDIO_BUFFER_SIZE];
static int16_t record_buffer[RECORD_BUFFER_SIZE];
static volatile uint32_t record_idx = 0;
static volatile uint32_t playback_idx = 0;
static volatile uint8_t audio_mode = 0;  // 0=idle, 1=recording, 2=playing

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2S2_Init(void);
static void MX_LPUART1_UART_Init(void);

/* USER CODE BEGIN PFP */
void Audio_Init(void);
void Audio_StartRecord(void);
void Audio_StopRecord(void);
void Audio_StartPlayback(void);
void Audio_StopPlayback(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

// 重定向printf到串口
#ifdef __GNUC__
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif

PUTCHAR_PROTOTYPE {
    HAL_UART_Transmit(&hlpuart1, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    return ch;
}

// I2S重新初始化
void I2S_Reconfig(uint32_t mode) {
    HAL_I2S_DMAStop(&hi2s2);
    HAL_I2S_DeInit(&hi2s2);
    
    hi2s2.Instance = SPI2;
    hi2s2.Init.Mode = mode;
    hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
    hi2s2.Init.DataFormat = I2S_DATAFORMAT_16B;
    hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_DISABLE;
    hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_16K;
    hi2s2.Init.CPOL = I2S_CPOL_LOW;
    HAL_I2S_Init(&hi2s2);
}

// 开始录音
void Audio_StartRecord(void) {
    if (audio_mode == 1) return;
    
    if (audio_mode == 2) {
        Audio_StopPlayback();
    }
    
    record_idx = 0;
    audio_mode = 1;
    
    I2S_Reconfig(I2S_MODE_MASTER_RX);
    HAL_I2S_Receive_DMA(&hi2s2, (uint16_t*)audio_buffer, AUDIO_BUFFER_SIZE);
    
    printf("[录音开始]\r\n");
}

// 停止录音
void Audio_StopRecord(void) {
    if (audio_mode != 1) return;
    
    HAL_I2S_DMAStop(&hi2s2);
    audio_mode = 0;
    
    printf("[录音结束] %lu 样本\r\n", record_idx);
}

// 填充播放缓冲区
void FillPlaybackBuffer(void) {
    for (int i = 0; i < AUDIO_BUFFER_SIZE; i += 2) {
        if (playback_idx < record_idx) {
            int16_t sample = record_buffer[playback_idx++];
            audio_buffer[i] = sample;      // 左声道
            audio_buffer[i+1] = sample;    // 右声道
        } else {
            audio_buffer[i] = 0;
            audio_buffer[i+1] = 0;
        }
    }
}

// 开始播放
void Audio_StartPlayback(void) {
    if (audio_mode == 2) return;
    
    if (audio_mode == 1) {
        Audio_StopRecord();
    }
    
    playback_idx = 0;
    audio_mode = 2;
    
    FillPlaybackBuffer();
    
    I2S_Reconfig(I2S_MODE_MASTER_TX);
    HAL_I2S_Transmit_DMA(&hi2s2, (uint16_t*)audio_buffer, AUDIO_BUFFER_SIZE);
    
    printf("[播放开始] %lu 样本\r\n", record_idx);
}

// 停止播放
void Audio_StopPlayback(void) {
    if (audio_mode != 2) return;
    
    HAL_I2S_DMAStop(&hi2s2);
    audio_mode = 0;
    
    printf("[播放结束]\r\n");
}

// PTT按键检测
bool PTT_Pressed(void) {
    return HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1) == GPIO_PIN_RESET;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void) {
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_LPUART1_UART_Init();
    MX_I2S2_Init();
    
    printf("\r\n========================================\r\n");
    printf("    MPTT Audio Test\r\n");
    printf("========================================\r\n");
    printf("Press PTT to record, release to play\r\n\r\n");
    
    bool last_ptt = false;
    
    while (1) {
        bool ptt = PTT_Pressed();
        
        // PTT按下 - 开始录音
        if (ptt && !last_ptt) {
            memset(record_buffer, 0, sizeof(record_buffer));
            record_idx = 0;
            Audio_StartRecord();
        }
        
        // PTT松开 - 停止录音，开始播放
        if (!ptt && last_ptt) {
            Audio_StopRecord();
            HAL_Delay(100);
            Audio_StartPlayback();
        }
        
        last_ptt = ptt;
        HAL_Delay(10);
    }
}

// DMA中断回调
void HAL_I2S_RxHalfCpltCallback(I2S_HandleTypeDef *hi2s) {
    if (hi2s != &hi2s2) return;
    // 处理前半缓冲区
    for (int i = 0; i < AUDIO_BUFFER_SIZE/2; i++) {
        if (record_idx < RECORD_BUFFER_SIZE) {
            // 32位转16位（INMP441输出32位，取高16位）
            record_buffer[record_idx++] = audio_buffer[i];
        }
    }
}

void HAL_I2S_RxCpltCallback(I2S_HandleTypeDef *hi2s) {
    if (hi2s != &hi2s2) return;
    // 处理后半缓冲区
    for (int i = AUDIO_BUFFER_SIZE/2; i < AUDIO_BUFFER_SIZE; i++) {
        if (record_idx < RECORD_BUFFER_SIZE) {
            record_buffer[record_idx++] = audio_buffer[i];
        }
    }
}

void HAL_I2S_TxHalfCpltCallback(I2S_HandleTypeDef *hi2s) {
    if (hi2s != &hi2s2) return;
    // 填充前半缓冲区
    for (int i = 0; i < AUDIO_BUFFER_SIZE/2; i += 2) {
        if (playback_idx < record_idx) {
            int16_t sample = record_buffer[playback_idx++];
            audio_buffer[i] = sample;
            audio_buffer[i+1] = sample;
        } else {
            audio_buffer[i] = 0;
            audio_buffer[i+1] = 0;
        }
    }
}

void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef *hi2s) {
    if (hi2s != &hi2s2) return;
    // 填充后半缓冲区
    for (int i = AUDIO_BUFFER_SIZE/2; i < AUDIO_BUFFER_SIZE; i += 2) {
        if (playback_idx < record_idx) {
            int16_t sample = record_buffer[playback_idx++];
            audio_buffer[i] = sample;
            audio_buffer[i+1] = sample;
        } else {
            audio_buffer[i] = 0;
            audio_buffer[i+1] = 0;
        }
    }
    
    // 播放完成检测
    if (playback_idx >= record_idx) {
        // 播放完最后一遍后重新开始
        playback_idx = 0;
    }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void) {
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_MSI;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.MSIState = RCC_MSI_ON;
    RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.MSICalibrationValue = RCC_MSICALIBRATION_DEFAULT;
    RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK3|RCC_CLOCKTYPE_HCLK
                                |RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1
                                |RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
    RCC_ClkInitStruct.AHBCLK3Divider = RCC_SYSCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) {
        Error_Handler();
    }
}

/**
  * @brief I2S2 Initialization Function
  */
static void MX_I2S2_Init(void) {
    hi2s2.Instance = SPI2;
    hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
    hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
    hi2s2.Init.DataFormat = I2S_DATAFORMAT_16B;
    hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_DISABLE;
    hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_16K;
    hi2s2.Init.CPOL = I2S_CPOL_LOW;
    if (HAL_I2S_Init(&hi2s2) != HAL_OK) {
        Error_Handler();
    }
}

/**
  * @brief LPUART1 Initialization Function
  */
static void MX_LPUART1_UART_Init(void) {
    hlpuart1.Instance = LPUART1;
    hlpuart1.Init.BaudRate = 115200;
    hlpuart1.Init.WordLength = UART_WORDLENGTH_8B;
    hlpuart1.Init.StopBits = UART_STOPBITS_1;
    hlpuart1.Init.Parity = UART_PARITY_NONE;
    hlpuart1.Init.Mode = UART_MODE_TX_RX;
    hlpuart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    hlpuart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
    hlpuart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
    hlpuart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    if (HAL_UART_Init(&hlpuart1) != HAL_OK) {
        Error_Handler();
    }
}

/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    // PTT按键 PA1
    GPIO_InitStruct.Pin = GPIO_PIN_1;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

/**
  * @brief DMA Initialization Function
  */
static void MX_DMA_Init(void) {
    __HAL_RCC_DMAMUX1_CLK_ENABLE();
    __HAL_RCC_DMA1_CLK_ENABLE();

    HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
    HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void) {
    __disable_irq();
    while (1) {
    }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line) {
}
#endif /* USE_FULL_ASSERT */
